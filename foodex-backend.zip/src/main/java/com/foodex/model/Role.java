package com.foodex.model;

public enum Role {
    CUSTOMER, RESTAURANT, DELIVERY
}
